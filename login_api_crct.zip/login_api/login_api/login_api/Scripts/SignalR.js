﻿$.connection.hub.start()
    .done(function ($scope) {
        console.log("working")

     $.connection.myHub.server.announce($scope.user1,$scope.user2);
    })
    .fail(function () { alert("error") });

$.connection.myHub.client.announce = function (message) { alert("message has been received") }
