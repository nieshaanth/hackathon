﻿app.controller('loginCtrl', function ($scope, $window, APIService) {
    $scope.init = function () {
        $scope.isProcessing = false;
        $scope.RegisterBtnText = "Login";
        $scope.RegisterBtnText1 = "Register ";

    };

    $scope.init();

    $scope.Login = function () {

        $scope.isProcessing = true;
        $scope.RegisterBtnText = "Please wait...";


        var obj = {
            emailId: $scope.email,
            passWord: $scope.password,
        }

        var servCall = APIService.login(obj);
        servCall.then(function (response) {

            getUserId($scope.email);
            $scope.email = '';
            $scope.password = '';
            $scope.f2.$setPristine();





        }, function (error) {
            alert("Invalid Username or Password");

            $scope.isProcessing = false;
            $scope.RegisterBtnText = "Login";
            $scope.email = '';
            $scope.password = '';
            $scope.f2.$setPristine();

        });


    };
    function getUserId(email) {

        var servCall = APIService.getUserId(email);
        servCall.then(function (response) {

            alert("You Will Be Redirected To Chat Page");
            $scope.userId = response.data;
            $window.sessionStorage.setItem('user', angular.toJson($scope.userId));

            $window.location.href = "chatpage.html";

        },
        function (error) {
            var error = error.status;
        })

    }
    $scope.saveUser = function () {
        $scope.isProcessing = true;
        $scope.RegisterBtnText1 = "Please wait...";
        var obj = {
            userName: $scope.signUpUserName,
            emailId: $scope.signUpEmailId,

            passWord: $scope.signUpPassword,
            question: "no",
            answer: "no"
        };

        var saveUser = APIService.saveUser(obj);
        saveUser.then(function (response) {






            alert("Registration Successfully Completed. Please sign in to Continue.");
            $scope.isProcessing = false;
            $scope.RegisterBtnText1 = "Register";
            $scope.signUpUserName = '';
            $scope.signUpEmailId = '';
            $scope.signUpPassword = '';


            $scope.f1.$setPristine();





        }
        , function (error) {
            alert("Email already existing")

            $scope.isProcessing = false;
            $scope.RegisterBtnText1 = "Register";
            $scope.signUpUserName = "";
            $scope.signUpEmailId = "";
            $scope.signUpPassword = "";
            $scope.f1.$setPristine();

        });

    };

});
