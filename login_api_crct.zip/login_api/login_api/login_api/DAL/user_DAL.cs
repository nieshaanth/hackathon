﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
using login_api.Models;
using login_api.Sql_Helper;

namespace login_api.DAL
{
    public class user_DAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

        public List<Users_Model> searchUser(string searchText)
        {
            SqlDataReader dr= sqlHelper.ExecuteReader(con, "searchUser",
                           new SqlParameter("@searchText", searchText));
            List<Users_Model> userList = new List<Users_Model>(); ;
            
            
            while(dr.Read())
            {
                Users_Model obj= new Users_Model();
                obj.userId=dr.GetInt32(0);
                obj.userName= dr.GetString(1);
                obj.emailId=dr.GetString(2);
                obj.logStatus=dr.GetString(3);
                userList.Add(obj);
            }
            return userList;
        }
        
        public bool addUser(Users_Model obj)
        {
            
            sqlHelper.ExecuteNonQuery(con, "addUser",
                new SqlParameter("@userName", obj.userName),
                new SqlParameter("@emailId", obj.emailId),
                new SqlParameter("@logStatus","true"),
            new SqlParameter("@userId",obj.userId));
            return true;
                      

        }

        public List<Users_Model> getContacts(int userId)
        {
            SqlDataReader dr = sqlHelper.ExecuteReader(con, "getContacts",
                           new SqlParameter("@userId", userId));
                 
            List<int> contactIds= new List<int>();
            while(dr.Read())
            {
                Chats_Model obj = new Chats_Model();
                if (userId == dr.GetInt32(1))
                {
                    contactIds.Add(dr.GetInt32(2));
                }
                else
                {
                    contactIds.Add(dr.GetInt32(1));
                }

            }
            dr.Close();
            
            List<Users_Model> contacts = new List<Users_Model>();
            for (int i = 0; i < contactIds.Count; i++)
            {
                dr = sqlHelper.ExecuteReader(con, "getUser",
                               new SqlParameter("@userId", contactIds[i]));

                while (dr.Read())
                {
                    Users_Model obj = new Users_Model();
                    obj.userId = dr.GetInt32(0);
                    obj.userName = dr.GetString(1);
                    obj.emailId = dr.GetString(2);
                    obj.logStatus = dr.GetString(3);
                    contacts.Add(obj);
                }
                dr.Close();
            }
            return contacts;
        }

        public int getUserId(string email)
        {
            
            SqlCommand com_getUserId= new SqlCommand("select userId from Users where emailId=@email",con);
            com_getUserId.Parameters.AddWithValue("@email",email);

            con.Open();
            int userid = Convert.ToInt32(com_getUserId.ExecuteScalar());

            return userid;


        }

        public bool chk_email(string emailId)
        {

            SqlCommand com_chkEmailid = new SqlCommand("select count(*) from Users where emailId=@email", con);
            com_chkEmailid.Parameters.AddWithValue("@email", emailId);
            con.Open();
            int count = Convert.ToInt32(com_chkEmailid.ExecuteScalar());
            if (count == 0)
            {
                con.Close();
                return true;
            }
            else
            {
                con.Close();
                return false;
            }




        }

    }
}