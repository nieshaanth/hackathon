﻿/// <reference path="module.js" />

app.controller('myCtrl', function ($scope, APIService,$window) {

    $scope.init = function (toUser) {
        $scope.count = 1;
        $scope.createChat(toUser);





    }

    getContacts($window.sessionStorage.getItem('user'));

    $scope.userId = $window.sessionStorage.getItem('user');

      
       
       
          $scope.createChat = function (toUser) {
                      
            if ($scope.count == 1) {
               
                $window.sessionStorage.setItem('toUser', angular.toJson(toUser));
                $scope.count++;
                
              }
            var fromUser = $window.sessionStorage.getItem('user')
        var servCall = APIService.createChat(fromUser,toUser);
        servCall.then(function (d) {
            $scope.chatHistory = d.data;
            
           
           
        }, function (error) {
            console.log('Oops! Something went wrong while getting the chat.')
        })
    }


          $scope.makeChat = function () {
            
            
                        var messageObj = {
                            fromUser: $window.sessionStorage.getItem('user'),
                            toUser: $window.sessionStorage.getItem('toUser'),
                            messageText: $scope.messageText,
                        };

                        
                      
                        var servCall = APIService.makeChat(messageObj);
              servCall.then(function (d)
              {
                  $scope.createChat($window.sessionStorage.getItem('toUser'));
                  

                      //$('#connection').val($window.sessionStorage.getItem('user'));

                      var fromUser = $window.sessionStorage.getItem('user');
                      var toUser = $window.sessionStorage.getItem('toUser');

                      $.connection.myHub.server.announce(fromUser, toUser);

                    

                 
                  $scope.messageText = '';
                  $scope.chat.$setPristine();
                })
              
              , function (error) {
                  console.log('Oops! Something went wrong while saving the data.')
              };
              //   $.connection.myHub.client.announce = function (fromUser, toUser) {
              //    if ($window.sessionStorage.getItem('user') == toUser) {
              //        alert('client push req');
              //        $scope.createChat(fromUser);
              //    }

              //}
          };

          $.connection.myHub.client.announce = function (fromUser, toUser) {
              if ($window.sessionStorage.getItem('user') == toUser) {
                 
                  $scope.createChat(fromUser);
              }

          }

    function getContacts (userId) {
        var servCall = APIService.getContacts(userId);
        servCall.then(function (response) {
            $scope.contacts = response.data;
            //$scope.sample = response.data[0];

            $.connection.hub.start()
        .done(function ($scope) {
            console.log("working")


        })
        .fail(function () { alert("error") });

        }, function (error) {

            var error = error.status;
        })
    }

    $scope.search = function () {

        var servCall = APIService.search($scope.searchText, $window.sessionStorage.getItem('user'));
        servCall.then(function (response) {
            $scope.contacts = response.data;
            
        }, function (error) {
        
            var error = error.status;
        })

    }
    function searchLoginUser(email) {

        var servCall = APIService.search(email);
        servCall.then(function (response) {
            $scope.loginUser = response.data;

        }, function (error) {

            var error = error.status;
        })

    }


});



 
