﻿


var app = angular.module('myApp', ['ngRoute']);
app.config(function ($routeProvider) {
    $routeProvider
    .when('/chat', {
        templateUrl: "chat.html"
    })
});