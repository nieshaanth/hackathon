﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using login_api.Models;
using login_api.Utils;
using login_api.DAL;
using System.Data.SqlClient;
using System.Web.Security;



namespace login_api.Controllers
{
    public class loginsController : ApiController
    {
        /// <summary>
        /// It adds a new user
        /// </summary>
        ///<description> It adds a new user </description>
        /// <returns>http status message</returns>
        /// <response code="201">Created</response>
        /// <response code="400">BadRequest</response>        
        /// <response code="500">InternalServerError</response>
        ///   <remarks>
        ///   new users registration
        ///   </remarks>
      

      


        [ResponseType(typeof(ResponseWrapper<Users_Model>))]
        [ActionName("createUser")]
        [HttpPost]
        public HttpResponseMessage createUser([FromBody]Users_Model mod_obj)
        {



            user_DAL dal_obj = new user_DAL();
            if (dal_obj.chk_email(mod_obj.emailId))
            {
                dal_obj.addUser(mod_obj);
                MembershipCreateStatus stat;
                Membership.CreateUser(mod_obj.emailId, mod_obj.passWord, mod_obj.emailId, mod_obj.question, mod_obj.answer, true, out stat);
                var err = new HttpResponseMessage(HttpStatusCode.Created);
                if (stat == MembershipCreateStatus.Success)
                {
                    err.ReasonPhrase = "Registration Successfully Completed. Please sign in to Continue.";
                    return err;
                }
                else
                {
                    err.ReasonPhrase = "Failed to add the user";
                    return err;
                }
            }
            else
            {



                var err = new HttpResponseMessage(HttpStatusCode.ExpectationFailed);
                err.ReasonPhrase = "Email Already Existing";
                return err;
            }


        }




        /// <summary>
        /// sign in page
        /// </summary>
        ///<description>user sign in </description>
        /// <returns>http status message</returns>
        /// <response code="201"> Created</response>
        /// <response code="400">BadRequest</response>        
        /// <response code="500">InternalServerError</response>
        ///   <remarks>
        ///    users  login
        ///   </remarks>

        [HttpPost]
        public HttpResponseMessage userlogin(Users_Model obj)
        {
            if (Membership.ValidateUser(obj.emailId, obj.passWord))
            {
                FormsAuthentication.SetAuthCookie(obj.emailId, true);
                return new HttpResponseMessage(HttpStatusCode.OK);

            }
            else
            {
                return new HttpResponseMessage(HttpStatusCode.NotFound);// return not valid 

            }

        }





        /// <summary>
        /// create chat
        /// </summary>
        ///<description>create page</description>
        /// <returns>http status message</returns>
        ///<param name="user1">  get /set id</param>
        ///<param name="user2">  get /set id</param>
        /// <response code="200">Created</response>     
        /// <response code="400">BadRequest</response>
        /// <response code="500">InternalServerError</response>
        ///   <remarks>
        ///    create the chat
        ///   </remarks>


        [HttpGet]
        public HttpResponseMessage createChat(int user1,int user2)
        {
            chat_DAL dal = new chat_DAL();
            Chats_Model obj = new Chats_Model();
            obj.fromUser = user1;
            obj.toUser = user2;

            if (dal.checkRoom(obj))
            {
                List<Chats_Model> chatHistory = dal.getOldChat(obj.roomId);
                return chatHistory.GetHttpResponseInstance();
                //return  serialize
            }
            else
            {
                dal.createRoom(obj);//null since new chat
                return null;
            }
        }

        /// <summary>
        /// It adds message to the DB
        /// </summary>
        ///<description>It adds message to the DB </description>
        /// <returns>http status message</returns>
        /// <response code="201">OK</response>
        /// <response code="400">BadRequest</response>        
        /// <response code="500">InternalServerError</response>
        ///   <remarks>
        ///   It adds message to the DB
        ///   </remarks>


        [ActionName("makeChat")]
        [HttpPost]
        public HttpResponseMessage makeChat(Chats_Model obj)
        {
            chat_DAL dal = new chat_DAL();
            List<Chats_Model> chatLatest=dal.makeChat(obj);
            return chatLatest.GetHttpResponseInstance();
        }



        /// <summary>
        /// Search User
        /// </summary>
        ///<description>Search User</description>
        /// <returns>http status message</returns>
        ///<param name="searchText">  get /set id</param>
        ///<param name="userId">  get /set id</param>
        /// <response code="200">Created</response>     
        /// <response code="400">BadRequest</response>
        /// <response code="500">InternalServerError</response>
        ///   <remarks>
        ///    Search User
        ///   </remarks>



        [HttpGet]
        public HttpResponseMessage searchUser(string searchText,int userId)//Used for search and getting userid by email
        {
            user_DAL dal = new user_DAL();
            List<Users_Model> tempList=dal.searchUser(searchText);
            //if (obj == null)
            var searchResult = tempList.Where(x => x.userId != userId).ToList();
                return searchResult.GetHttpResponseInstance();//null handling
        }



        /// <summary>
        ///Get contacts
        /// </summary>
        ///<description>Get contacts</description>
        ///<param name="userId">  get /set id</param>
        /// <returns>http status message</returns>
        /// <response code="200">Created</response>     
        /// <response code="400">BadRequest</response>
        /// <response code="500">InternalServerError</response>
        ///   <remarks>
        ///   Get contacts
        ///   </remarks>

        [HttpGet]
      public HttpResponseMessage contacts(int userId)
        {
            user_DAL dal = new user_DAL();
            List<Users_Model> contacts = dal.getContacts(userId);
            if (contacts == null)
            {
                return new HttpResponseMessage(HttpStatusCode.NotFound);
            }
            else
            {
                return contacts.GetHttpResponseInstance();
            }
            
        }




        /// <summary>
        /// Get UserId
        /// </summary>
        ///<description>Get UserId</description>
        /// <returns>http status message</returns>
        ///<param name="email">  get /set id</param>
        /// <response code="200">Created</response>     
        /// <response code="400">BadRequest</response>
        /// <response code="500">InternalServerError</response>
        ///   <remarks>
        ///     Get Userid
        ///   </remarks>



        [HttpGet]
        public HttpResponseMessage getUserId(string email)
        {
            user_DAL dal = new user_DAL();
            int userId = dal.getUserId(email);

            return userId.GetHttpResponseInstance();

        } 
 




  
    }
    }

