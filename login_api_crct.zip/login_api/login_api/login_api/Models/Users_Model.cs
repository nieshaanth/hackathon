﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
using System.Runtime.Serialization;
namespace login_api.Models
{
    [DataContract]
    public class Users_Model
    {
        /// <summary>
        /// name=userId
        /// Description=user id
        /// </summary>
        [DataMember]
        public int userId { get;set;}

        /// <summary>
        /// name=userName
        /// Description=user name
        /// </summary>
        [DataMember]
        public string userName { get; set; }

        /// <summary>
        /// name=emailId
        /// Description=email
        /// </summary>
        [DataMember]
        public string emailId { get; set; }

        /// <summary>
        /// name=logStatus
        /// Description=log status
        /// </summary>
        [DataMember]
        public string logStatus { get; set; }


        /// <summary>
        /// name=passWord
        /// Description=password
        /// </summary>
        [DataMember]
        public string passWord { get; set; }

        /// <summary>
        /// name=question
        /// Description=question
        /// </summary>
        [DataMember]
        public string question { get; set; }

        /// <summary>
        /// name=answer
        /// Description=securiy answer
        /// </summary>
        [DataMember]
        public string answer { get; set; }


    }
}