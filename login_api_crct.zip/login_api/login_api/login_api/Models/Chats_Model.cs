﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
using System.Runtime.Serialization;

namespace login_api.Models
{
    public class Chats_Model
    {
        /// <summary>
        /// name=roomId   
        /// Description=Id for each user
        /// </summary>
        [DataMember]
        public int roomId { get; set; }
        /// <summary>
        /// name=fromUser       
        /// Description=Id for each from user
        /// </summary>
        [DataMember]
        public int fromUser { get; set; }
        /// <summary>
        /// name=toUser       
        /// Description=Id for each recepient
        /// </summary>
        [DataMember]
        public int toUser { get; set; }
        /// <summary>
        /// name=messageText    
        /// Description=message text
        /// </summary>
        [DataMember]
        public string messageText { get; set; }
        /// <summary>
        /// name=sentTime
        /// Description=sent Time
        /// </summary>
        [DataMember]
        public DateTime sentTime { get; set; }


    }   
}