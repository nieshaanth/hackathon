﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Net.Http.Headers;
using System.Net.Http;
using Newtonsoft.Json;
using System.Net;
using Newtonsoft.Json.Serialization;

namespace login_api.Utils
{
    
        public static class Extensions
        {
            public static HttpResponseMessage GetHttpResponseInstance(this object objJsonNetResult)
            {

                HttpContext.Current.Response.Cache.VaryByHeaders["Accept-encoding"] = true;

                var stringContent =
                    new StringContent(JsonConvert.SerializeObject(objJsonNetResult, new JsonSerializerSettings() { ContractResolver = new CamelCasePropertyNamesContractResolver() }));

                var responseHttp = new HttpResponseMessage

                {

                    StatusCode = HttpStatusCode.OK,

                    Content = stringContent

                };

                responseHttp.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");

                return responseHttp;

            }
            private static ResponseWrapper<object> ValidateandBuildResponseData(object unFormattedResponse)
            {
                var responseData = new ResponseWrapper<object>()
                {
                    metaData = GetMetatdata(unFormattedResponse),
                    data = unFormattedResponse
                };
                return responseData;
            }
            private static Metadata GetMetatdata(object data, bool isError = false, string errorCode = "", string errorDescription = "")
            {

                var errorObject = new ErrorReponse();
                errorObject.code = errorCode;
                errorObject.message = errorDescription;
                return new Metadata()
                {
                    description = data == null ? "Data Not Available" : "Transaction Successful",
                    error = errorObject
                };
            }


        
    }
}