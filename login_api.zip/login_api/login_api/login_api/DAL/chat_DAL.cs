﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
using login_api.Models;
using login_api.Sql_Helper;

namespace login_api.DAL
{
    public class chat_DAL
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

        public  List<Chats_Model> getOldChat(int roomId)
        {
               SqlDataReader dr = sqlHelper.ExecuteReader(con, "getChat",
                new SqlParameter("@roomId", roomId));
            List<Chats_Model> chatlist= new List<Chats_Model>();
            while (dr.Read())
            {
                Chats_Model obj = new Chats_Model();
                obj.roomId = dr.GetInt32(0);
                obj.fromUser = dr.GetInt32(1);
                obj.toUser = dr.GetInt32(2);
                obj.messageText = dr.GetString(3);
                obj.sentTime = dr.GetDateTime(4);
                chatlist.Add(obj);
            }
            return chatlist;
        }

        public bool checkRoom(Chats_Model obj)
        {
            obj.roomId=Convert.ToInt32(sqlHelper.ExecuteScalar(con, "isRoom",
                new SqlParameter("@user1", obj.fromUser),
                new SqlParameter("@user2", obj.toUser)));
            if (obj.roomId == 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        public int createRoom(Chats_Model obj)
        {
            sqlHelper.ExecuteScalar(con, "newRoom",
                      new SqlParameter("@user1", obj.fromUser),
                   new SqlParameter("@user2", obj.toUser),
                   new SqlParameter("@roomId", obj.roomId));
            return obj.roomId;
        }
        public List<Chats_Model> makeChat(Chats_Model obj)
        {

            obj.roomId=Convert.ToInt32(sqlHelper.ExecuteScalar(con, "isRoom",
                new SqlParameter("@user1", obj.fromUser),
                new SqlParameter("@user2", obj.toUser)));
            
            sqlHelper.ExecuteNonQuery(con,"chats",
                new SqlParameter("@roomId",obj.roomId),
                new SqlParameter("@fromUser",obj.fromUser),
                new SqlParameter("@toUser",obj.toUser),
                new SqlParameter("@messageText",obj.messageText),
                new SqlParameter("@sentTime",DateTime.Now)
                );
            chat_DAL dal= new chat_DAL();
            List<Chats_Model> chatlist = dal.getOldChat(obj.roomId);// 
            return chatlist;
  

        }
    }
}