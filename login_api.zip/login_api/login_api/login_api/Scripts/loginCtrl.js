﻿/// <reference path="module.js" />
app.controller('loginCtrl', function ($scope, myservice, $window, APIService) {

   
    $scope.Login = function () {

        var servCall = APIService.login($scope.email,$scope.password);
        servCall.then(function (response) {
            alert('in login');
            getUserId($scope.email);
           

           
        }, function () {
            $scope.myResponse = "Invalid Username or Password";
        });

       
    };
    function getUserId(email) {
        alert(email);
        var servCall = APIService.getUserId(email);
        servCall.then(function (response) {
            alert('hai');
           
            $scope.userId = response.data;
            $window.sessionStorage.setItem('user', angular.toJson($scope.userId));
            alert($scope.userId);
            $window.location.href = "chatpage.html";

        },
        function (error) {
            var error = error.status;
        })

    }
    $scope.saveUser = function () {
        alert("inside save user");
        var obj = {
            userName: $scope.signUpUserName,
            emailId: $scope.signUpEmailId,

            passWord: $scope.signUpPassword,
            question: "no",
            answer: "no"
        };

        var saveUser = APIService.saveUser(obj);
        saveUser.then(function (response) {
            $scope.signUpResponse = response.status;
            $window.location.href = "Index.html";
        }
        , function (response) {
            $scope.signUpResponse = response.status;

        });

    };
   
});