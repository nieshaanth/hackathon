﻿app.controller('loginCtrl', function ($scope, $window, APIService) {
    $scope.init = function () {
        $scope.isProcessing = false;
        $scope.RegisterBtnText = "Login";
        $scope.RegisterBtnText1 = "Register ";

    };

    $scope.init();

    $scope.Login = function () {
        $scope.isProcessing = true;
        $scope.RegisterBtnText = "Please wait...";
        alert('in')
        var servCall = APIService.login($scope.email, $scope.password);
        servCall.then(function (response) {

            getUserId($scope.email);




        }, function (error) {
            alert("Invalid Username or Password");
            $scope.isProcessing = false;
            $scope.RegisterBtnText = "Login";

        });


    };
    function getUserId(email) {

        var servCall = APIService.getUserId(email);
        servCall.then(function (response) {

            alert("You Will Be Redirected To Chat Page");
            $scope.userId = response.data;
            $window.sessionStorage.setItem('user', angular.toJson($scope.userId));
            alert($scope.userId);
            $window.location.href = "chatpage.html";

        },
        function (error) {
            var error = error.status;
        })

    }
    $scope.saveUser = function () {
        $scope.isProcessing = true;
        $scope.RegisterBtnText1 = "Please wait...";
        var obj = {
            userName: $scope.signUpUserName,
            emailId: $scope.signUpEmailId,

            passWord: $scope.signUpPassword,
            question: "no",
            answer: "no"
        };

        var saveUser = APIService.saveUser(obj);
        saveUser.then(function (response) {


            alert("Registration Successfully Completed. Please sign in to Continue.");

        }
        , function (response) {
            alert("Error occured. Please try again.");
            $scope.isProcessing = false;
            $scope.RegisterBtnText1 = "Register";

        });

    };

});
