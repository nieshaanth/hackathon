﻿/// <reference path="module.js" />

app.controller('myCtrl', function ($scope, APIService,$window) {
  //  var flag;
   

        getContacts($window.sessionStorage.getItem('user'));
        //flag = 1;
      //  $scope.email = angular.fromJson();
       // var email = $scope.email;
        $scope.userId = $window.sessionStorage.getItem('user');
  
  
    
    //if (flag == 1)
    //{
    //    getUserId($scope.email);
    //    flag = 2;

       
    //}

    //getContacts(userData);
 
 //   createChat();
   

        $scope.createChat = function (toUser) {
            // $window.sessionStorage.setItem('fromUser', angular.toJson(fromUser));
           // if ($scope.count == 1) {
                $window.sessionStorage.setItem('toUser', angular.toJson(toUser));
                $scope.count++;
           // }
            var fromUser = $window.sessionStorage.getItem('user')
        var servCall = APIService.createChat(fromUser,toUser);
        servCall.then(function (d) {
            $scope.myAnswer = d.data;
        }, function (error) {
            $log.error('Oops! Something went wrong while fetching the data.')
        })
    }


    $scope.makeChat = function () {
        var messageObj = {
            fromUser: $window.sessionStorage.getItem('user'),
            toUser: $window.sessionStorage.getItem('toUser'),
            messageText: $scope.messageText,
            };
        var servCall = APIService.makeChat(messageObj);
        servCall.then(function (d) {
            $scope.createChat($window.sessionStorage.getItem('toUser'));
        }, function (error) {
            console.log('Oops! Something went wrong while saving the data.')
        })
    };

    function getContacts (userId) {
        var servCall = APIService.getContacts(userId);
        servCall.then(function (response) {
            $scope.contacts = response.data;
              
        }, function (error) {

            var error = error.status;
        })
    }

    $scope.search = function () {

        var servCall = APIService.search($scope.searchText);
        servCall.then(function (response) {
            $scope.contacts = response.data;
            
        }, function (error) {
        
            var error = error.status;
        })

    }
    function searchLoginUser(email) {

        var servCall = APIService.search(email);
        servCall.then(function (response) {
            $scope.loginUser = response.data;

        }, function (error) {

            var error = error.status;
        })

    }


});



 
