﻿/// <reference path="module.js" />

app.controller('myCtrl', function ($scope, APIService,$window) {

    $scope.init = function (toUser) {
        $scope.count = 1;
        $scope.createChat(toUser);
    }
        getContacts($window.sessionStorage.getItem('user'));
       
        $scope.userId = $window.sessionStorage.getItem('user');
       
          $scope.createChat = function (toUser) {
                      
            if ($scope.count == 1) {
                alert($scope.count);
                $window.sessionStorage.setItem('toUser', angular.toJson(toUser));
                $scope.count++;
                alert($scope.count);
              }
            var fromUser = $window.sessionStorage.getItem('user')
        var servCall = APIService.createChat(fromUser,toUser);
        servCall.then(function (d) {
            $scope.myAnswer = d.data;
        }, function (error) {
            console.log('Oops! Something went wrong while getting the chat.')
        })
    }


          $scope.makeChat = function () {
              alert($scope.messageText);
              alert('to user:' + $window.sessionStorage.getItem('toUser'));
                        var messageObj = {
                            fromUser: $window.sessionStorage.getItem('user'),
                            toUser: $window.sessionStorage.getItem('toUser'),
                            messageText: $scope.messageText,
                        };

                        alert($scope.messageText);
                        alert(messageObj.messageText);
                        var servCall = APIService.makeChat(messageObj);
              servCall.then(function (d) {
                  $scope.createChat($window.sessionStorage.getItem('toUser'));
                  $.connection.hub.start()
                  .done(function ($scope) {
                      console.log("working");
                      
                      var fromUser = $window.sessionStorage.getItem('user');
                      var toUser = $window.sessionStorage.getItem('toUser');

                      $.connection.myHub.server.announce(fromUser, toUser);

                  }).fail(function () { alert("error") });
                })
              
              , function (error) {
                  console.log('Oops! Something went wrong while saving the data.')
              };
                

              $.connection.myHub.client.announce = function (fromUser, toUser) {
                  $scope.createChat(fromUser);

              }
    };

    function getContacts (userId) {
        var servCall = APIService.getContacts(userId);
        servCall.then(function (response) {
            $scope.contacts = response.data;
              
        }, function (error) {

            var error = error.status;
        })
    }

    $scope.search = function () {

        var servCall = APIService.search($scope.searchText);
        servCall.then(function (response) {
            $scope.contacts = response.data;
            
        }, function (error) {
        
            var error = error.status;
        })

    }
    function searchLoginUser(email) {

        var servCall = APIService.search(email);
        servCall.then(function (response) {
            $scope.loginUser = response.data;

        }, function (error) {

            var error = error.status;
        })

    }


});



 
