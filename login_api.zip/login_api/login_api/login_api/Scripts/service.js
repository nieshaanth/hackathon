﻿app.service("APIService", function ($http) {

    this.createChat = function (fromUser, toUser) {
        var str = 'http://localhost:63164/logins/createChat?user1=';
        var link = str + fromUser + '&user2=' + toUser;
        return $http.get(link);
    }

    this.makeChat = function (messageObj) {
        return $http(
        {
            method: 'post',
            data: messageObj,
            url: 'http://localhost:63164/logins/makeChat'
        });
    }

    this.saveUser = function (obj) {
        return $http({
            method: 'post',
            data: obj,
            url: 'http://localhost:63164/logins/createUser'

        });
    }
      
    this.login = function (obj) { 
       
      
        return $http({ 
            method: 'post', 
            data:obj, 
            url: 'http://localhost:63164/logins/userlogin'   
        }) 
}


  

    this.getContacts = function (userId) {
        var str = "http://localhost:63164/logins/contacts?userId=";
        var link = str + userId;
        return $http.get(link);
    }
    this.search = function (searchText,userId) {

        var link = "http://localhost:63164/logins/searchUser?searchText="+searchText+"&userId=" +userId ;
        return $http.get(link);

    }

    this.getUserId = function (email) {
        alert('inside serv call()service');
        var link = "http://localhost:63164/logins/getUserId?email=" + email;
        return $http.get(link);

    }
    
});