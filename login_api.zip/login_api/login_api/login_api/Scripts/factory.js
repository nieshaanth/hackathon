﻿/// <reference path="controller.js" />
/// <reference path="loginCtrl.js" />
/// <reference path="module.js" />
app.factory('myservice', function () {
    var savedData;
    return {
        set: function (data) {
            this.savedData = data;
            alert(savedData);
        },
        get: function () {
            alert(savedData);
            return this.savedData;
        }

    }
}
);

