﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using login_api.Models;
using login_api.Utils;
using login_api.DAL;
using System.Data.SqlClient;
using System.Web.Security;



namespace login_api.Controllers
{
    public class loginsController : ApiController
    {      
  
        [ResponseType(typeof(ResponseWrapper<Users_Model>))]
        [ActionName("createUser")]
        [HttpPost]
        public HttpResponseMessage createUser([FromBody]Users_Model mod_obj)
        {

                  if (mod_obj == null)
            {
                return new HttpResponseMessage(HttpStatusCode.BadRequest);
            }
            else
            {
                user_DAL dal_obj = new user_DAL();
                dal_obj.addUser(mod_obj);
                 MembershipCreateStatus stat;
                 Membership.CreateUser(mod_obj.emailId, mod_obj.passWord, mod_obj.emailId, mod_obj.question, mod_obj.answer, true, out stat);
                    var err = new HttpResponseMessage(HttpStatusCode.Created);
                    if (stat == MembershipCreateStatus.Success)
                    {
                        err.ReasonPhrase = "Id added successfully";
                        return err;
                    }
                    else
                    {
                        err.ReasonPhrase = "Id not added successfully";
                        return err;
                    }
                
            }
        }

        [HttpPost]
        public HttpResponseMessage userlogin(string username, string password, bool rememberme)
        {
            if (Membership.ValidateUser(username, password))
            {
                FormsAuthentication.SetAuthCookie(username, rememberme);
                return new HttpResponseMessage(HttpStatusCode.OK);

            }
            else
            {
                return new HttpResponseMessage(HttpStatusCode.NotFound);// return not valid

            }

        } 




        [HttpGet]
        public HttpResponseMessage createChat(int user1,int user2)
        {
            chat_DAL dal = new chat_DAL();
            Chats_Model obj = new Chats_Model();
            obj.fromUser = user1;
            obj.toUser = user2;

            if (dal.checkRoom(obj))
            {
                List<Chats_Model> chatHistory = dal.getOldChat(obj.roomId);
                return chatHistory.GetHttpResponseInstance();
                //return  serialize
            }
            else
            {
                dal.createRoom(obj);//null since new chat
                return null;
            }
        }

        [ActionName("makeChat")]
        [HttpPost]
        public HttpResponseMessage makeChat(Chats_Model obj)
        {
            chat_DAL dal = new chat_DAL();
            List<Chats_Model> chatLatest=dal.makeChat(obj);
            return chatLatest.GetHttpResponseInstance();
        }

        [HttpGet]
        public HttpResponseMessage searchUser(string searchText)//Used for search and getting userid by email
        {
            user_DAL dal = new user_DAL();
            List<Users_Model> searchResult=dal.searchUser(searchText);
            //if (obj == null)
                return searchResult.GetHttpResponseInstance();//null handling
        }

        [HttpGet]
      public HttpResponseMessage contacts(int userId)
        {
            user_DAL dal = new user_DAL();
            List<Users_Model> contacts = dal.getContacts(userId);
            if (contacts == null)
            {
                return new HttpResponseMessage(HttpStatusCode.NotFound);
            }
            else
            {
                return contacts.GetHttpResponseInstance();
            }
            
        }

        [HttpGet]
        public HttpResponseMessage getUserId(string email)
        {
            user_DAL dal = new user_DAL();
            int userId = dal.getUserId(email);

            return userId.GetHttpResponseInstance();

        }
  
    }
    }

