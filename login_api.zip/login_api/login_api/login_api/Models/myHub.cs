﻿using Microsoft.AspNet.SignalR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using login_api.DAL;
using login_api.Controllers;
namespace login_api.Models
{
    public class myHub : Hub
    {

        public void Announce(int user1,int user2)
        {
            loginsController obj= new loginsController();

            obj.createChat(user1, user2);
            Clients.Caller.Announce();
        }
    }
}