﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
using System.Runtime.Serialization;
namespace login_api.Models
{
    [DataContract]
    public class Users_Model
    {
        [DataMember]
        public int userId { get;set;}
        [DataMember]
        public string userName { get; set; }
        [DataMember]
        public string emailId { get; set; }
        [DataMember]
        public string logStatus { get; set; }
        [DataMember]
        public string passWord { get; set; }
        [DataMember]
        public string question { get; set; }
        [DataMember]
        public string answer { get; set; }


    }
}