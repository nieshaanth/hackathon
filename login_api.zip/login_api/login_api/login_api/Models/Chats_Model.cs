﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
using System.Runtime.Serialization;

namespace login_api.Models
{
    public class Chats_Model
    {

        [DataMember]
        public int roomId { get; set; }
        [DataMember]
        public int fromUser { get; set; }
        [DataMember]
        public int toUser { get; set; }
        [DataMember]
        public string messageText { get; set; }
        [DataMember]
        public DateTime sentTime { get; set; }


    }   
}