﻿using Microsoft.AspNet.SignalR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using login_api.DAL;
using login_api.Controllers;
namespace login_api.Models
{
    public class myHub : Hub
    {

        public void Announce(int fromUser, int toUser)
        {
           // string str = toUser.ToString();
           
           
            //GlobalHost.DependencyResolver.Register(typeof(string), () => str);   

            Clients.All.Announce(fromUser,toUser);
            
        }
    }
}