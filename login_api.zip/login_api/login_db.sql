Create database Prattle

use Prattle

Create table users
(
userId int identity(1000,1) primary key,
name varchar(30),
emailId varchar(30),
logStatus bit
)

alter procedure addUser
@userName varchar(max),
@emailId varchar(max),
@logStatus bit,
@userId int out
As
Begin
insert users(name,emailId,logStatus)values (@userName,@emailId,@logStatus)
set @userId=@@IDENTITY
select @@IDENTITY
return @userId
end







